//
//  Football.swift
//  Caio_721914_MAD3004_MidtermTest
//
//  Created by MacStudent on 2018-02-07.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class Football: Sports{
    
    //5. Create a protocol to display necessary information from Sports and Cricket classes.
    override func DisplayInformation(){
        print("Football:")
        print("NumberOfMinutes: ", self.NumberOfMinutes)
        print("NumberOfMinutesPlayed: ", self.NumberOfMinutesPlayed)
        print("NumberOfGoalsScored: ", self.NumberOfGoalsScored)
        print("TotalRedCardIssued: ", self.TotalRedCardIssued)
        print("PenaltyTime: ", self.PenaltyTime)
        print("PenaltyShootoutGoals: ", self.PenaltyShootoutGoals)
        super.DisplayInformation();
        print(" ")
    }
    
    var NumberOfMinutes: Int
    var NumberOfMinutesPlayed: Int
    var NumberOfGoalsScored: Int
    var TotalRedCardIssued: Int
    var PenaltyTime: Int
    var PenaltyShootoutGoals: Int

    
    override init(){
        self.NumberOfMinutes = 0;
        self.NumberOfMinutesPlayed = 0;
        self.NumberOfGoalsScored = 0;
        self.TotalRedCardIssued = 0;
        self.PenaltyTime = 0;
        self.PenaltyShootoutGoals = 0;
        super.init()
    }
    
    init(pNumberOfMinutes: Int, pNumberOfMinutesPlayed: Int, pNumberOfGoalsScored: Int, pTotalRedCardIssued: Int,  pPenaltyTime: Int, pPenaltyShootoutGoals: Int, pSportsType: Int, pNumberOfPlayers: Int){
        self.NumberOfMinutes = pNumberOfMinutes
        self.NumberOfMinutesPlayed = pNumberOfMinutesPlayed
        self.NumberOfGoalsScored = pNumberOfGoalsScored
        self.TotalRedCardIssued = pTotalRedCardIssued
        self.PenaltyTime = pPenaltyTime
        self.PenaltyShootoutGoals = pPenaltyShootoutGoals

        super.init(pSportsType: pSportsType, pNumberOfPlayers: pNumberOfPlayers)
    }
    
    //7. Call different methods of Cricket and Football class and display output in proper format.
    func ShowNumbersOfPlayersInTrouble(){
        print("The number of players in trouble is \(self.TotalRedCardIssued)")
    }
    func ShowTimeTheTeamReceivePenalty(){
        print("The team received a penalty of \(self.PenaltyTime)")
    }
    
    func addNumberNewPlayers( _ numberNewPlayersAdded: Int) -> () -> Int{
        var totalPlayersAdded: Int = 0;
        
        func increment() -> Int{
            totalPlayersAdded += numberNewPlayersAdded
            return totalPlayersAdded;
        }
        
        return increment;
    }
}
