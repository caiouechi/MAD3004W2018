//
//  main.swift
//  Caio_721914_MAD3004_MidtermTest
//
//  Created by MacStudent on 2018-02-07.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

//6. Create at least two objects of Cricket and Football classes each
var cricketObject1 = Cricket(pNumberOfOversPerInning: 7, pTotalWicketsDown: 10, pTotalRunsScored: 60, pTotalOversPlayed: 40, pFormatCricket: 2, pSportsType: 1, pNumberOfPlayers: 30)
cricketObject1.DisplayInformation()

var cricketObject2 = Cricket(pNumberOfOversPerInning: 11, pTotalWicketsDown: 22, pTotalRunsScored: 70, pTotalOversPlayed: 35, pFormatCricket: 1, pSportsType: 0, pNumberOfPlayers: 130)
cricketObject2.DisplayInformation()

var footballObject1 = Football(pNumberOfMinutes: 30, pNumberOfMinutesPlayed: 50, pNumberOfGoalsScored: 10, pTotalRedCardIssued: 3, pPenaltyTime: 5, pPenaltyShootoutGoals: 10, pSportsType: 1, pNumberOfPlayers: 10)
footballObject1.DisplayInformation()

var footballObject2 = Football(pNumberOfMinutes: 22, pNumberOfMinutesPlayed: 51, pNumberOfGoalsScored: 15, pTotalRedCardIssued: 2, pPenaltyTime: 12, pPenaltyShootoutGoals: 11, pSportsType: 0, pNumberOfPlayers: 13)
footballObject1.DisplayInformation()

//7. Call different methods of Cricket and Football class and display output in proper format.
print("Different methods of Cricket:")
cricketObject1.ShowNumberOfScores();
cricketObject1.ShowTotalOversPlayed();

//A different method in Cricket class using dicitonary.
var cricketDictionary = cricketObject1.CreateDictionaryInfo();
print("   Display Dictionary info: ")
for (k,v) in cricketDictionary{
    print("   \(k): \(v)")
}
print(" ");

print("Different methods of Footbal:")
footballObject1.ShowTimeTheTeamReceivePenalty();
footballObject1.ShowNumbersOfPlayersInTrouble();

//A different method in Footbal class using optional label parameter, nested closure and increment variable.
var numberPlayersAdded = footballObject1.addNumberNewPlayers(2);
print("   Total number of new Players Added in August: \(numberPlayersAdded())")
print("   Total number of new Players Added in September: \(numberPlayersAdded())")
print("   Total number of new Players Added in October: \(numberPlayersAdded())")

