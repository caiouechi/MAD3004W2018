//
//  Protocols.swift
//  Caio_721914_MAD3004_MidtermTest
//
//  Created by MacStudent on 2018-02-07.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

//5. Create a protocol to display necessary information from Sports and Cricket classes.
protocol IDisplay{
    func DisplayInformation()
}
