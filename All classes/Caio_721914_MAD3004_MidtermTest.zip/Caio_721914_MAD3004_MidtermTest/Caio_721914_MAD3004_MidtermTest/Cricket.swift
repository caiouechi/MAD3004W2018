//
//  Cricket.swift
//  Caio_721914_MAD3004_MidtermTest
//
//  Created by MacStudent on 2018-02-07.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation


class Cricket: Sports{
    
    //5. Create a protocol to display necessary information from Sports and Cricket classes.
    override func DisplayInformation(){
        print("Cricket:")
        
        if self.FormatCricket == 0 {
              print("FormatCricket: t-20 [", self.FormatCricket, "]")
        }else if (self.FormatCricket == 1) {
            print("FormatCricket: testmatch [", self.FormatCricket, "]")
        }else {
            print("FormatCricket: one day [", self.FormatCricket, "]")
        }
    
        print("NumberOfOversPerInning: ", self.NumberOfOversPerInning)
        print("TotalWicketsDown: ", self.TotalWicketsDown)
        print("TotalRunsScored: ", self.TotalRunsScored)
        print("TotalOversPlayed: ", self.TotalOversPlayed)
        print("AverageRunRate: ", self.AverageRunRate)
        super.DisplayInformation();
        print(" ")
    }
    
    //0: t-20
    //1: testmatch
    //2: one day
    var FormatCricket: Int
    
    var NumberOfOversPerInning: Int
    var TotalWicketsDown: Int
    var TotalRunsScored: Int
    var TotalOversPlayed: Int
    var AverageRunRate: Float {
        get {return (Float)( (Float)(self.TotalRunsScored)/(Float)(self.TotalOversPlayed))}
    }
    
    override init(){
        self.NumberOfOversPerInning = 0;
        self.TotalWicketsDown = 0;
        self.TotalRunsScored = 0;
        self.TotalOversPlayed = 0;
        self.FormatCricket = 0;
        super.init()
    }
    
    init(pNumberOfOversPerInning: Int, pTotalWicketsDown: Int, pTotalRunsScored: Int, pTotalOversPlayed: Int, pFormatCricket: Int  ,pSportsType: Int, pNumberOfPlayers: Int){
        self.NumberOfOversPerInning = pNumberOfOversPerInning
        self.TotalWicketsDown = pTotalWicketsDown
        self.TotalRunsScored = pTotalRunsScored
        self.TotalOversPlayed = pTotalOversPlayed
        self.FormatCricket = pFormatCricket;

        super.init(pSportsType: pSportsType, pNumberOfPlayers: pNumberOfPlayers)
    }
    
    //7. Call different methods of Cricket and Football class and display output in proper format.
    func ShowNumberOfScores(){
         print("The number of scores the team Got was \(self.TotalRunsScored)")
    }
    
    func ShowTotalOversPlayed(){
         print("The number of overs played was \(self.TotalOversPlayed)")
    }
    
    func CreateDictionaryInfo() -> Dictionary<String, Int>{
        var dictionaryReturn: Dictionary<String, Int> = ["FormatCricket" : self.FormatCricket];
        
        dictionaryReturn["NumberOfOversPerInning"] = self.NumberOfOversPerInning;
        dictionaryReturn["TotalWicketsDown"] = self.TotalWicketsDown;
        dictionaryReturn["TotalRunsScored"] = self.TotalRunsScored;
        dictionaryReturn["TotalOversPlayed"] = self.TotalOversPlayed;
        dictionaryReturn["AverageRunRate"] = (Int)(self.AverageRunRate);
        
        return dictionaryReturn;
    }
}
