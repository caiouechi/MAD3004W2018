//
//  Sports.swift
//  Caio_721914_MAD3004_MidtermTest
//
//  Created by MacStudent on 2018-02-07.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class Sports: IDisplay{
    
    //5. Create a protocol to display necessary information from Sports and Cricket classes.
    func DisplayInformation() {
        print("  Sports:")
        
        if SportsType == 0 {
            print("  SportsType: indoor [", self.SportsType, "]")
        }else{
            print("  SportsType: outdoor [", self.SportsType, "]")
        }
            print("  NumberOfPlayers: ", self.NumberOfPlayers)
                                }
    //0: indoor
    //1: outdoor
    var SportsType: Int
    var NumberOfPlayers: Int
    
    init(){
        self.SportsType = 0;
        self.NumberOfPlayers = 0;
    }
    
    init(pSportsType: Int, pNumberOfPlayers: Int){
        self.SportsType = pSportsType;
        self.NumberOfPlayers = pNumberOfPlayers
    }
}
