//
//  ShippingInfo.swift
//  Day6
//
//  Created by Kuljeet Singh on 2018-02-05.
//  Copyright © 2018 Kuljeet Singh. All rights reserved.
//

import Foundation

class ShippingInfo: Orders {

    private var shippingType: String?
    private var shippingCost: Int?
    private var shippingRegionID: Int?
    
    //get and setters
    var ShippingType: String?{
        get{return shippingType} set{shippingType = newValue}
    }
    var ShippingCost: Int?{
        get{return shippingCost} set{shippingCost = newValue}
    }
    
    override func displayData() -> String{
        var returnVariable = "";
        
        returnVariable = "ShippinngInfo properties" + "\n"
        //ShippingInfo
        if self.shippingType != nil {returnVariable += "shippingType: \(self.shippingType!) \n"}
        if self.shippingCost != nil {returnVariable += "shippingCost: \(self.shippingCost!) \n"}
        if self.shippingRegionID != nil {returnVariable += "shippingRegionID: \(self.shippingRegionID!) \n"}
  
        //Orders
        if self.orderID != nil {returnVariable += "orderID: \(self.orderID!) \n"}
        if self.DateCreated != nil {returnVariable += "dateCreated: " + self.DateCreated! + "\n"}
        if self.DateShipped != nil {returnVariable += "dateShipped: " + self.DateShipped! + "\n"}
        if self.Status != nil {returnVariable += "status: " + self.Status! + "\n"}
        
        //Customer
        returnVariable += "customerID: " + self.customerID! + "\n"
        if CustomerName != nil {returnVariable += "customerName: " + CustomerName! + "\n"}
        if Address != nil {returnVariable += "address: " + Address! + "\n"}
        if Email != nil {returnVariable += "email: " + Email! + "\n"}
        if CreditCardInfo != nil {returnVariable += "creditCardInfo: " + CreditCardInfo! + "\n"}
        if ShippingInfo != nil {returnVariable += "shippingInfo: " + ShippingInfo! + "\n"}
        
        //User
        returnVariable += "  userID: " + self.userID! + "\n"
        if Password != nil {returnVariable += "  password: " + HelperValidator.starPassword(self.Password!) + "\n"}
        if LoginStatus != nil {returnVariable += "  loginStatus" + LoginStatus! + "\n"}
        
        return returnVariable;
    }
    
    override init() {

        self.shippingType = ""
        self.shippingCost = 0
        self.shippingRegionID = 0
        super.init()
    }
    
    init(sShippingID: String, sShippingType:String, sShippingCost: Int, sShippingRegionID: Int, pOrderID: Int, pCustomerID: String,pUserID: String) {

        self.shippingType = sShippingType
        self.shippingCost = sShippingCost
        self.shippingRegionID = sShippingRegionID
            super.init(pOrderID: pOrderID, pCustomerID: pCustomerID,pUserID: pUserID)
    }
    
    func updateShippingInfo(updateAddress: String?, updateEmail: String?) {
        if updateAddress == nil{
            print("Add New address for shipping: ")
            let updateAddress = readLine()!
        }
        
        if updateEmail == nil{
            print("add new email: ")
            let updateEmail = readLine()!
        }
        
        super.Address = updateAddress
        super.Email = updateEmail
        print("Data added")
    }
    

}
