//
//  Customer.swift
//  Day6
//
//  Created by Kuljeet Singh on 2018-02-05.
//  Copyright © 2018 Kuljeet Singh. All rights reserved.
//

import Foundation

class Customer : User {
    //customerID is gonna be the link between Shopping Cart entity, Orders entity with Customer entity
    //every customer has userID, but not the reverse
    var customerID: String?
    private var customerName : String?
    private var address : String?
    private var email : String?
    private var creditCardInfo : String?
    private var shippingInfo : String?
    
    //get and setters
    var CustomerName : String? {
        get{return customerName} set{customerName = newValue;}
    }
    var Address : String?{
        get{return address} set{address = newValue}		
    }
    var Email : String?{
        get{return email} set{email = newValue}
    }
    var CreditCardInfo : String?{
        get{return creditCardInfo} set{creditCardInfo = newValue}
    }
    var ShippingInfo : String?{
        get{return shippingInfo} set{shippingInfo = newValue}
    }
    
    
    
    
    override func displayData() -> String {
        var returnVariable = "";

        returnVariable = "Printing Customer properties" + "\n"
        returnVariable += "customerID: " + self.customerID! + "\n"
        
        if self.CustomerName != nil {returnVariable += "customerName: " + self.CustomerName! + "\n"}
        if self.Address != nil {returnVariable += "address: " + self.Address! + "\n"}
        if self.Email != nil {returnVariable += "email: " + self.Email! + "\n"}
        if self.CreditCardInfo != nil {returnVariable += "creditCardInfo: " + self.CreditCardInfo! + "\n"}
        if self.ShippingInfo != nil {returnVariable += "shippingInfo: " + self.ShippingInfo! + "\n"}
        if self.userID != nil {returnVariable += "  userID: " + self.userID! + "\n"}

        //User
        if Password != nil {returnVariable += "  password: " + HelperValidator.starPassword(self.Password!) + "\n"}
        if LoginStatus != nil {returnVariable += "  loginStatus" + LoginStatus! + "\n"}
        
        return returnVariable;
    }
    
    override init() {
        self.customerID = ""
        self.customerName = ""
        self.address = ""
        self.email = ""
        self.creditCardInfo = ""
        self.shippingInfo = ""
        
        super.init()
    }
    
    init(pCustomerID: String, pCustomerName: String, pAddress: String, pEmail: String, pCreditCardInfo: String, pShippingInfo: String, pUserID: String) {
        self.customerID = pCustomerID
        self.customerName = pCustomerName
        self.address = pAddress
        self.email = pEmail
        self.creditCardInfo = pCreditCardInfo
        self.shippingInfo = pShippingInfo
        
        super.init(userID: pUserID)
    }
    
    init(pCustomerID: String, pUserID: String){
        self.customerID = pCustomerID
        super.init(userID: pUserID)
    }
    
    
 
    func register() {
        print("Enter Name:")
        CustomerName = readLine()!
        print("Enter Add:")
        Address = readLine()!
        print("Enter E-Mail:")
        Email = readLine()!
        print("Enter Password : ")
        super.Password = readLine()!
        print("Enter Credit Info:")
        CreditCardInfo = readLine()!
        print("Enter Shipping Info:")
        ShippingInfo = readLine()!
        print("User was registestered in success")

    }
    
    func login() {
        print("Enter User Name:")
        super.userID = readLine()!
        print("Enter Password:")
        Password = readLine()!
        super.verifyLogin(userID : userID!, custPass : Password!,id :self.email!)
    }
    
    func updateProfile(updateName: String, updateAdd: String, updateMail: String) {
        print("Welcome User : \(userID!)")
        print("Name: ")
        let updateName = readLine()
        print("Address:")
        let updateAdd = readLine()
        print("Email")
        let updateMail = readLine()
        self.customerName = updateName
        self.address = updateAdd
        self.email = updateMail
    }
    

    func select()
    {
        print("-------------------")
        print("1. Register")
        print("2. Login")
        print("-------------------")
        
        let cust1 = Int(readLine()!)
        
        if cust1 == 1
        {
            register()
        }
            
        else if cust1 == 2
        {
            login()
        }
        
    }
    
}
