//
//  Helper.swift
//  FinalProject_Swift
//
//  Created by MacStudent on 2018-02-13.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

public struct HelperValidator{
    
    static func starPassword(_ Password: String) -> String{
        var returnPass = ""
        
        for i in Password {
            returnPass += "*"
        }
        return returnPass
    }
    
}
