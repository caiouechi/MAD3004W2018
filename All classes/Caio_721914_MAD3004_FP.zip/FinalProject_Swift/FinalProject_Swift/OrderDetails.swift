//
//  OrderDetails.swift
//  Day6
//
//  Created by Kuljeet Singh on 2018-02-05.
//  Copyright © 2018 Kuljeet Singh. All rights reserved.
//

import Foundation

class OrderDetails: Orders
{
    var orderId: Int?
    var productId: Int?
   private var productName: String?
   private var quantity: Int?
   private var unitCost: Float?
   private var subtotal: Float?
    
    var ProductName: String?{
        get{return productName} set{productName = newValue}
    }
    var Quantity: Int?{
        get{return quantity} set{quantity = newValue}
    }
    var UnitCost: Float?{
        get{return unitCost} set{unitCost = newValue}
    }
    var Subtotal: Float?{
        get{return subtotal} set{subtotal = newValue}
    }
    
    override init() {
        self.orderId = 0
        self.productId = 0
        self.productName = ""
        self.quantity = 0
        self.unitCost = 0
        self.subtotal = 0
        super.init()
    }
    
    override func displayData() -> String {
        var returnVariable = "";
        
        returnVariable = "Order detail properties" + "\n"
        if self.orderId != nil {returnVariable += "orderId: \(self.orderId!) \n"}
        if self.productId != nil {returnVariable += "productId:  \(self.productId!) \n"}
        if self.ProductName != nil {returnVariable += "productName: " + ProductName! + "\n"}
        if self.Quantity != nil {returnVariable += "quantity:  \(Quantity!)  \n"}
        if self.UnitCost != nil {returnVariable += "unitCost:  \(UnitCost!)  \n"}
        if self.Subtotal != nil {returnVariable += "subtotal:  \(Subtotal!)  \n"}

        //Orders
        if self.orderID != nil {returnVariable += "orderID: \(self.orderID!) \n"}
        if self.DateCreated != nil {returnVariable += "dateCreated: " + self.DateCreated! + "\n"}
        if self.DateShipped != nil {returnVariable += "dateShipped: " + self.DateShipped! + "\n"}
        if self.Status != nil {returnVariable += "status: " + self.Status! + "\n"}
        
        //Customer
        returnVariable += "customerID: " + self.customerID! + "\n"
        if CustomerName != nil {returnVariable += "customerName: " + CustomerName! + "\n"}
        if Address != nil {returnVariable += "address: " + Address! + "\n"}
        if Email != nil {returnVariable += "email: " + Email! + "\n"}
        if CreditCardInfo != nil {returnVariable += "creditCardInfo: " + CreditCardInfo! + "\n"}
        if ShippingInfo != nil {returnVariable += "shippingInfo: " + ShippingInfo! + "\n"}
        
        //User
        returnVariable += "  userID: " + self.userID! + "\n"
        if Password != nil {returnVariable += "  password: " + HelperValidator.starPassword(self.Password!) + "\n"}
        if LoginStatus != nil {returnVariable += "  loginStatus" + LoginStatus! + "\n"}
        
        return returnVariable;
    }
    
    init(oId: Int , oPId:Int , oPName:String , oQuantity:Int , oUCost:Float , oSubTotal:Float, pOrderID: Int, pCustomerID: String, pUserID: String)
    {
        self.orderId = oId
        self.productId = oPId
        self.productName = oPName
        self.quantity = oQuantity
        self.unitCost = oUCost
        self.subtotal = oSubTotal
        super.init(pOrderID: pOrderID, pCustomerID: pCustomerID,pUserID: pUserID)
    }
    
    func calcPrice() -> Float {
        subtotal = 0
        subtotal = Float(unitCost! * Float(quantity!))
        return subtotal!
    }
}
