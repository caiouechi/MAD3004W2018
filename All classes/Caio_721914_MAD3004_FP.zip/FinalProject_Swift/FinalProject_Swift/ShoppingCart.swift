//
//  ShoppingCart.swift
//  Day6
//
//  Created by Kuljeet Singh on 2018-02-05.
//  Copyright © 2018 Kuljeet Singh. All rights reserved.
//

import Foundation

class ShoppingCart: Orders {
    var cartID: Int?
    var productID: Int?
    var quantity: Int?
    var dateAdded: Int?
    var cartItems: [String]
    
    //get and setters
    var Quantity: Int?{
        get{return quantity} set{quantity = newValue}
    }
    var DateAdded: Int?{
        get{return dateAdded} set{dateAdded = newValue}
    }
    
    override func displayData() -> String{
        var returnVariable = "";
        
        returnVariable = "ShoppingCart properties" + "\n"
        //ShoppingCart
        if self.cartID != nil {returnVariable += "cartID: \(self.cartID!) \n"}
        if self.productID != nil {returnVariable += "productID: \(self.productID!) \n"}
        if self.Quantity != nil {returnVariable += "quantity: \(self.Quantity!) \n"}
        if self.DateAdded != nil {returnVariable += "dateAdded: \(self.DateAdded!) \n"}
        
        //Orders
        if self.orderID != nil {returnVariable += "orderID: \(self.orderID!) \n"}
        if self.DateCreated != nil {returnVariable += "dateCreated: " + self.DateCreated! + "\n"}
        if self.DateShipped != nil {returnVariable += "dateShipped: " + self.DateShipped! + "\n"}
        if self.Status != nil {returnVariable += "status: " + self.Status! + "\n"}
        
        //Customer
        returnVariable += "customerID: " + self.customerID! + "\n"
        if CustomerName != nil {returnVariable += "customerName: " + CustomerName! + "\n"}
        if Address != nil {returnVariable += "address: " + Address! + "\n"}
        if Email != nil {returnVariable += "email: " + Email! + "\n"}
        if CreditCardInfo != nil {returnVariable += "creditCardInfo: " + CreditCardInfo! + "\n"}
        if ShippingInfo != nil {returnVariable += "shippingInfo: " + ShippingInfo! + "\n"}
        
        //User
        returnVariable += "  userID: " + self.userID! + "\n"
        if Password != nil {returnVariable += "  password: " + HelperValidator.starPassword(self.Password!) + "\n"}
        if LoginStatus != nil {returnVariable += "  loginStatus" + LoginStatus! + "\n"}
        
        return returnVariable;
    }
    
    
    override init() {
        cartID = 0
        productID = 0
        quantity = 0
        dateAdded = 0
        self.cartItems = [String]();
        super.init()
    }
    
    init(pCartID:Int, pProductID: Int, pQuantity: Int, pDateAdded:Int, pOrderID:Int, pShippingID: String, pCustomerID: String,pUserID: String) {
        self.cartID = pCartID
        self.productID = pProductID
        self.quantity = pQuantity
        self.dateAdded = pDateAdded
        self.cartItems = [String]();
        super.init(pOrderID: pOrderID, pCustomerID: pCustomerID,pUserID: pUserID)
    }
    
    func addCartItem() {
        print("Enter Item Code to be added in the cart:")
        var newItem = readLine()
        self.cartItems.insert(newItem!, at: self.cartItems.endIndex)
        
        print("Item \(newItem) added")
    }
    
    func updateQuantity() {
        print("Enter the Item to have the quantity updated:")
        var newItem = readLine()
        
        print("Enter new Quantity:")
        var newQuantity = readLine()!
        if newQuantity.isNumber {
            self.quantity = (Int)(newQuantity)
            print("The item \(newItem) has now a quantity of \(self.quantity!)")
        }else{
            print("You have inserted an invalid quantity, please try again.")
        }
    }

    func viewCardDetails() {
        print("Credit Card Information : ", CreditCardInfo!)
    }

    func checkOut() {
        placeOrder()
    }
}
