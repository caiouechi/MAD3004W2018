//
//  Extensions.swift
//  CaioKuljeetRohan_MAD3004_FP.zip
//
//  Created by MacStudent on 2018-02-13.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

//Check if the input of the user is a number or not
extension String  {
    var isNumber: Bool {
        return !isEmpty && rangeOfCharacter(from: CharacterSet.decimalDigits.inverted) == nil
    }
}
