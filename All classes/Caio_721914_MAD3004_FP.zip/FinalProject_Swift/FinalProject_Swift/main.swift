//
//  main.swift
//  FinalProject_Swift
//
//  Created by MacStudent on 2018-02-13.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation


//7. In order to test the output, you must create at least 2 objects of each non_abstract class
var firstObjectAdministrator = Administrator(aName: "Caio", aEmail: "caio_uechi@hotmail.com", cUserID: "3")
print(firstObjectAdministrator.displayData())

var secondObjectAdministrator = Administrator(aName: "Kuljeet", aEmail: "kuljeet@gmail", cUserID: "4")
print(secondObjectAdministrator.displayData())

var firstObjectCustomer = Customer(pCustomerID: "1", pCustomerName: "Kye", pAddress: "15 Bathurst Street", pEmail: "kye@hotmail.com", pCreditCardInfo: "VISA", pShippingInfo: "Delivered", pUserID: "1")
print(firstObjectCustomer.displayData());

var secondObjectCustomer = Customer(pCustomerID: "2", pCustomerName: "Bruna", pAddress: "15 Uol Street", pEmail: "Bruna@hotmail.com", pCreditCardInfo: "MasterCard", pShippingInfo: "Pending", pUserID: "2")
print(secondObjectCustomer.displayData());

var firstObjectOrderDetails = OrderDetails(oId: 1, oPId: 1, oPName: "Mobile", oQuantity: 3, oUCost: 24.8, oSubTotal: 49, pOrderID: 1, pCustomerID: "1", pUserID: "1")
print(firstObjectOrderDetails.displayData())

var secondObjectOrderDetails = OrderDetails(oId: 1, oPId: 1, oPName: "iPad", oQuantity: 5, oUCost: 224.8, oSubTotal: 549, pOrderID: 2, pCustomerID: "2", pUserID: "2")
print(firstObjectOrderDetails.displayData())

var firstObjectOrders = Orders(pOrderID: 1, pDateCreated: "11-11-2011", pDateShipped: "12-11-2011", pStatus: "Success", pCustomerID: "1", pUserID: "1")
print(firstObjectOrders.displayData())

var secondObjectOrders = Orders(pOrderID: 2, pDateCreated: "11-11-2011", pDateShipped: "09-11-2011", pStatus: "Pending", pCustomerID: "2", pUserID: "2")
print(secondObjectOrders.displayData())

var firstObjectShippingInfo = ShippingInfo(sShippingID: "1", sShippingType: "Fast", sShippingCost: 30, sShippingRegionID: 1, pOrderID: 1, pCustomerID: "1", pUserID: "1")
print(firstObjectShippingInfo.displayData())

var secondObjectShippingInfo = ShippingInfo(sShippingID: "2", sShippingType: "Normal", sShippingCost: 80, sShippingRegionID: 2, pOrderID: 2, pCustomerID: "2", pUserID: "2")
print(secondObjectShippingInfo.displayData())

var firstObjectShoppingCart = ShoppingCart(pCartID: 1, pProductID: 1, pQuantity: 28, pDateAdded: 1, pOrderID: 1, pShippingID: "1", pCustomerID: "1", pUserID: "1")
print(firstObjectShoppingCart.displayData())

var secondObjectShoppingCart = ShoppingCart(pCartID: 2, pProductID: 2, pQuantity: 2, pDateAdded: 2, pOrderID: 2, pShippingID: "2", pCustomerID: "2", pUserID: "2")
print(secondObjectShoppingCart.displayData())

var firstObjectUser = User(userID: "1", pass: "pass123", lstatus: "Active")
print(firstObjectUser.displayData())

var secondObjectUser = User(userID: "2", pass: "ohmygod123", lstatus: "Active")
print(secondObjectUser.displayData())


//Manual tests
//var newShoppingCart = ShoppingCart()
//newShoppingCart.addCartItem()
//newShoppingCart.updateQuantity()
//var obj1 = ShippingInfo()
//print("Update shipping information: ")
//obj1.updateShippingInfo(updateAddress: nil, updateEmail: nil)

/*
 Start menu
 print("Menu")
 print("1. Customer")
 print("2. Administrator")
 let menu = Int(readLine()!)
 switch menu {
 case 1?: let c1 = Customer()
 c1.select()
 case 2?: let a1 = Administrator()
 a1.adminLogin()
 default: print("Select any option")
 }
 */


