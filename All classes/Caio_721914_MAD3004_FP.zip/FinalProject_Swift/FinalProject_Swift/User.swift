//
//  User.swift
//  Day6
//
//  Created by Kuljeet Singh on 2018-02-05.
//  Copyright © 2018 Kuljeet Singh. All rights reserved.
//

import Foundation

class User: IDisplay{
    var userID : String?
    private var password : String?
    private var loginStatus : String?
    
    //Get and Setters
    var Password: String? {
        get {return self.password;} set {self.password = newValue;}
    }
    var LoginStatus: String? {
        get {return self.loginStatus;} set {self.loginStatus = newValue;}
    }
    
    init() {
        userID = ""
        //Default values
        password = "123456"
        loginStatus = "Active"
    }
    
    init(userID: String, pass: String, lstatus: String) {
        self.userID = userID
        self.password = pass
        self.loginStatus = lstatus
    }

    init(userID: String) {
        self.userID = userID
    }

    //functions
    func displayData() -> String {
        var returnVariable = "";
        
        returnVariable = "Printing User properties" + "\n"
        returnVariable += "userID: " + self.userID! + "\n"
        if Password != nil {returnVariable += "  password: " + HelperValidator.starPassword(self.Password!) + "\n"}
        if self.LoginStatus != nil {returnVariable += "loginStatus: " + self.LoginStatus! + "\n"}
        
             return returnVariable;
    }
    
    func verifyLogin(userID: String, custPass: String,id: String) -> Bool {
        /* verification login */
        
        if (userID == id && password == custPass) {
            let customerValue = Customer()
            print("Login Successful")
            return true
        }
        else {
            print("Try Again")
            return false
        }
    }
}

