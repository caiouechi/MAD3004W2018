//
//  Administrator.swift
//  Day6
//
//  Created by Kuljeet Singh on 2018-02-05.
//  Copyright © 2018 Kuljeet Singh. All rights reserved.
//

import Foundation

class Administrator: User {
    
    private var  adminName : String?
    private var  email : String?
    
    //Get and Setters
    var AdminName: String?{
        get{return adminName} set{adminName = newValue}
    }
    var Email: String?{
        get{return email;} set{email = newValue}
    }
    
    override init() {
        self.adminName = ""
        self.email = ""
        super.init()
    }
    
    func updateCatalog() -> Bool {
        return true
    }
    
    init(aName: String, aEmail: String,cUserID: String) {
        self.adminName = aName
        self.email = aEmail
        super.init(userID: cUserID)
    }
    
    //functions
    override func displayData() -> String {
        var returnVariable = "";
        
        returnVariable = "Printing Administrator properties" + "\n"
        returnVariable += "adminName: " + AdminName! + "\n"
        returnVariable += "email: " + Email! + "\n"
        returnVariable += "  userID: " + self.userID! + "\n"
        
        //User
        if Password != nil {returnVariable += "  password: " + HelperValidator.starPassword(self.Password!) + "\n"}
        if LoginStatus != nil {returnVariable += "  loginStatus" + LoginStatus! + "\n"}
        
        return returnVariable;
    }
    
    func updateCatalog(pUpdateName: String, pUpdateAdd: String, pUpdateMail: String, pUpdateAddress: String, pUpdateEmail: String){
        print("you wanna update")
        print("1) updateProfile")
        print("2) update shipping info")
        
        let prof = Int(readLine()!)
        if prof == 1
        {
            var newCustomer = Customer()
            newCustomer.updateProfile(updateName: pUpdateName, updateAdd: pUpdateAdd, updateMail: pUpdateMail)
        }
        else if (prof == 2)
        {
            var newUpdateShippingInfo = ShippingInfo()
            newUpdateShippingInfo.updateShippingInfo(updateAddress: pUpdateAddress, updateEmail: pUpdateEmail)
        }
    }
    
    //Extra method
    func adminLogin()
    {
        print("Insert Admin Name : ")
        adminName = readLine()!
        print("Insert E-Mail ID : ")
        email = readLine()!
        if adminName == "admin" && email == "admin@admin.com"
        {
            print("Admin Login Success")
        }
        else
        {
            print("Invalid data")
        }
    }
    
}
