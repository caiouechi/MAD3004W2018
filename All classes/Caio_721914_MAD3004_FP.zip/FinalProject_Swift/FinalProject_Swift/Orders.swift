//
//  Orders.swift
//  Day6
//
//  Created by Kuljeet Singh on 2018-02-05.
//  Copyright © 2018 Kuljeet Singh. All rights reserved.
//

import Foundation

class Orders: Customer {
   
    var orderID: Int?
    private var dateCreated: String?
    private var dateShipped: String?
    private var status: String?
    //Removed shippingID because we used Heritage
    //var shippingID: String?
    
    //get and setters
    var DateCreated: String?{
        get{return dateCreated;} set{dateCreated = newValue}
    }
    var DateShipped: String?{
        get{return dateShipped} set{dateShipped = newValue}
    }
    var Status: String?{
        get{return status} set{status = newValue}
    }
    
    override func displayData() -> String {
        var returnVariable = "";
        
        returnVariable = "Order properties" + "\n"

        //Orders
        if self.orderID != nil {returnVariable += "orderID: \(self.orderID!) \n"}
        if self.DateCreated != nil {returnVariable += "dateCreated: " + self.DateCreated! + "\n"}
        if self.DateShipped != nil {returnVariable += "dateShipped: " + self.DateShipped! + "\n"}
        if self.Status != nil {returnVariable += "status: " + self.Status! + "\n"}
        
        //Customer
        returnVariable += "customerID: " + self.customerID! + "\n"
        if CustomerName != nil {returnVariable += "customerName: " + CustomerName! + "\n"}
        if Address != nil {returnVariable += "address: " + Address! + "\n"}
        if Email != nil {returnVariable += "email: " + Email! + "\n"}
        if CreditCardInfo != nil {returnVariable += "creditCardInfo: " + CreditCardInfo! + "\n"}
        if ShippingInfo != nil {returnVariable += "shippingInfo: " + ShippingInfo! + "\n"}
        
        //User
        returnVariable += "  userID: " + self.userID! + "\n"
        if Password != nil {returnVariable += "  password: " + HelperValidator.starPassword(self.Password!) + "\n"}
        if LoginStatus != nil {returnVariable += "  loginStatus" + LoginStatus! + "\n"}
        
        return returnVariable;
    }
    
    override init() {
        self.orderID = 0
        self.dateCreated = ""
        self.dateShipped = ""
        self.status = ""
        //self.shippingID = ""
        super.init()
    }
    
    init(pOrderID:Int, pDateCreated:String, pDateShipped:String, pStatus: String, pCustomerID: String,pUserID: String) {
        self.orderID = pOrderID
        self.dateCreated = pDateCreated
        self.dateShipped = pDateShipped
        self.status = pStatus
        
        
        super.init(pCustomerID: pCustomerID,pUserID: pUserID)
    }
    
    init(pOrderID:Int, pCustomerID: String,pUserID: String){
        self.orderID = pOrderID
        super.init(pCustomerID: pCustomerID, pUserID: pUserID)
    }
    
    func placeOrder() -> Bool {
        if status == "Approved" {
            return true
        }
        else {
            return false
        }
        
    }
}
