//
//  TestB.swift
//  Day7Protocols
//
//  Created by Jigisha Patel on 2018-02-06.
//  Copyright © 2018 JK. All rights reserved.
//

import Foundation

class TestB: TestA{
    var n2: Int?
    
    override func display() {
        print("Inside Class B")
    }
    
    override func displayValue() {
        print("VAlue of n2 : \(n2!)")
    }
}
