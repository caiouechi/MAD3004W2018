//
//  Grades.swift
//  Day6
//
//  Created by Jigisha Patel on 2018-02-04.
//  Copyright © 2018 JK. All rights reserved.


import Foundation

class Grades : Student{
    
    //read-only computed property
    var total: Int{
        get{
            return markSub1! + markSub2! + markSub3!
        }
    }
    
    //read-only computed property
    var percentage: Double{
        get{
            return Double(total / 3)
        }
    }
    
    //read-only computed property
    var result: String{
        get{
            return "Pass"
        }
    }
    
    override init(){
        super.init()
    }
    
    init(name1: String, id1: Int, markSub11: Int, markSub21: Int, markSub31: Int){
        super.init(name: name1, id: id1, markSub1: markSub11, markSub2: markSub21, markSub3: markSub31)
    }
    
    override func display() {
        super.display()
        print("Total : ",total)
        print("Percentage : ",percentage)
        print("Result : ",result)
    }
}

