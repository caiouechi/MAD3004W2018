//
//  Student.swift
//  Day6
//
//  Created by Jigisha Patel on 2018-02-04.
//  Copyright © 2018 JK. All rights reserved.
//

import Foundation

class Student
{
    var name: String?
    var id: Int?
    var markSub1: Int?
    var markSub2: Int?
    var markSub3: Int?
    
    init()
    {
        self.name = ""
        self.id = 0
        self.markSub1 = 0
        self.markSub2 = 0
        self.markSub3 = 0
    }
    
    init(name: String, id: Int, markSub1: Int, markSub2: Int, markSub3: Int){
        self.name = name
        self.id = id
        self.markSub1 = markSub1
        self.markSub2 = markSub2
        self.markSub3 = markSub3
    }
    
    func display()
    {
        print("Name : ",name!)
        print("Id : ",id!)
        print("Subject 1 : ",markSub1!)
        print("Subject 2 : ",markSub2!)
        print("Subject 3 : ",markSub3!)
    }
}

