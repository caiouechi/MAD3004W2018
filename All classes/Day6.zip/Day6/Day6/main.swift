//
//  main.swift
//  Day6
//
//  Created by Jigisha Patel on 2018-02-04.
//  Copyright © 2018 JK. All rights reserved.
//

import Foundation

/*
 var s1 = Student()
 s1.id=1
 s1.name="JK"
 s1.markSub1=50
 s1.markSub2=50
 s1.markSub3=50
 
 print("object s1========= ")
 s1.display()
 */

/*
var allStudents = [Student]()
var snm:String?
var sid:Int?
var sm1:Int?
var sm2:Int?
var sm3:Int?

for _ in 0..<2{
    print("Enter Name: ")
    snm = readLine()
    print("Enter id: ")
    sid = Int(readLine()!)
    print("Enter marks 1: ")
    sm1 = Int(readLine()!)
    print("Enter marks 2: ")
    sm2 = Int(readLine()!)
    print("Enter marks 3: ")
    sm3 = Int(readLine()!)
    
    allStudents.append(Student(name: snm!,id: sid!, markSub1: sm1!, markSub2: sm2!, markSub3: sm3!))
}

for i in 0..<2{
    allStudents[i].display()
}

//Grades object
//var gradeStud1 = Grades(name1: "JK", id1: 38, markSub11: 45, markSub21: 56, markSub31: 67, total1: 100, percentage1: 30.2, result1: "Pass")
//print("Grades object=======")
//gradeStud1.display()

//Grades object
var gradeStud2 = Grades(name1: "Jigisha Patel", id1: 32, markSub11: 100, markSub21: 100, markSub31: 100)
print("Grades object with Computed Properties=======")
gradeStud2.display()

*/
