//
//  main.swift
//  Singleton
//
//  Created by Jigisha Patel on 2018-02-15.
//  Copyright © 2018 JK. All rights reserved.
//

import Foundation

//'MySingleton' initializer is inaccessible due to 'private' protection level
//var s1 = MySingleton()
//print(MySingleton.instant.getMyName());

print(MySingleton.getInstant().getMyName())
