//
//  creditLimit.swift
//  ErrorHandling
//
//  Created by Jigisha Patel on 2018-02-08.
//  Copyright © 2018 JK. All rights reserved.
//

import Foundation

enum limitIncreaseError: Error{
    case insuffucientBalance(balanceNeeded: Double)
    case noSavingAccount
    case ineligible
}

struct requestsFromAccount{
    var type: String
    var balance: Double
    var reqStatus: String
}


