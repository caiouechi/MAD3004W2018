//
//  Person.swift
//  OptionalChaining
//
//  Created by Jigisha Patel on 2018-02-12.
//  Copyright © 2018 JK. All rights reserved.
//

import Foundation

class Person {
    var residence: Residence?
}
