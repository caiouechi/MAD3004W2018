//
//  Room.swift
//  OptionalChaining
//
//  Created by Jigisha Patel on 2018-02-12.
//  Copyright © 2018 JK. All rights reserved.
//

import Foundation

class Room {
    let name: String
    init(name: String) { self.name = name }
}
