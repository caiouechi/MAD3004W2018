//
//  main.swift
//  StaticThings
//
//  Created by MacStudent on 2018-02-14.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

var e1 = Employee()
print(Employee.getNoOfObject())
e1.greet(name: "Sona1")
var e2 = Employee()
print(Employee.getNoOfObject())

var p1 = PartTime()
p1.greet(name: "p1")

e1 = p1
e1.greet(name: "NAME")

var r1: Employee
r1 = Employee()
r1.greet(name: "Employee")

r1 = PartTime()
r1.greet(name: "Parttime")

//Reference
p1 = e1 as! PartTime
p1.greet(name: "Naveen")


//JSON
let tutorial = Tutorial(title: "What's new in swift 4", author: "Cosmin", editor: "Simon", type: "Swift", publishDate: Date())

//Encoder
let encoder = JSONEncoder()
let data = try encoder.encode(tutorial)
let jsonString = String(data: data, encoding: .utf8)

print(jsonString ?? "")

//Decoder
let decoder = JSONDecoder()
let article = try decoder.decode(Tutorial.self, from : data)
let info = "\(article.title) \(article.author) \(article.editor) \(article.type) \(article.publishDate)"

//Challenge, try to create a propperty with another type
//Challenge2, try to create a property of a list type




