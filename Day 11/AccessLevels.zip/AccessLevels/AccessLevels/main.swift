//
//  main.swift
//  AccessLevels
//
//  Created by MacStudent on 2018-02-12.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

print("Hello, World!")

//open, public, internal, file-private, private


//var objStud = Student()
//objStud.display

//var objFullTime = FullTime()


class T: ExtendPartTime{
    override init(){
        super.init()
        print("Dsiplay T")
    }
}

var t1 = T()
